import { create } from 'zustand';
import { Subreddit, SubredditPost } from '../types/reddit';

interface SubredditState {
  subscribedSubreddits: Subreddit[];
  currentPosts: SubredditPost[];
  isLoading: boolean;
  subscribe: (subreddit: Subreddit) => void;
  unsubscribe: (subredditId: string) => void;
  fetchPosts: (subredditName: string) => Promise<void>;
}

export const useSubredditStore = create<SubredditState>((set) => ({
  subscribedSubreddits: [],
  currentPosts: [],
  isLoading: false,

  subscribe: (subreddit) => {
    set((state) => ({
      subscribedSubreddits: [...state.subscribedSubreddits, subreddit],
    }));
  },

  unsubscribe: (subredditId) => {
    set((state) => ({
      subscribedSubreddits: state.subscribedSubreddits.filter(
        (sub) => sub.id !== subredditId
      ),
    }));
  },

  fetchPosts: async (subredditName) => {
    set({ isLoading: true });
    try {
      // TODO: Implement actual Reddit API call
      const mockPosts: SubredditPost[] = [];
      set({ currentPosts: mockPosts, isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw new Error('Failed to fetch posts');
    }
  },
}));