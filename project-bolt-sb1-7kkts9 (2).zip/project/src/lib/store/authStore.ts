import { create } from 'zustand';
import { AuthState, User } from '../types/auth';

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,

  login: async (email: string, password: string) => {
    try {
      // TODO: Implement actual API call
      const mockUser: User = {
        id: '1',
        username: 'testuser',
        email: email,
      };
      set({ user: mockUser, isAuthenticated: true });
    } catch (error) {
      throw new Error('Login failed');
    }
  },

  register: async (username: string, email: string, password: string) => {
    try {
      // TODO: Implement actual API call
      const mockUser: User = {
        id: '1',
        username,
        email,
      };
      set({ user: mockUser, isAuthenticated: true });
    } catch (error) {
      throw new Error('Registration failed');
    }
  },

  logout: () => {
    set({ user: null, isAuthenticated: false });
  },
}));