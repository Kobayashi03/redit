export interface SubredditPost {
  id: string;
  title: string;
  author: string;
  thumbnail: string;
  url: string;
  created: number;
  score: number;
  numComments: number;
  permalink: string;
}

export interface Subreddit {
  id: string;
  name: string;
  displayName: string;
  description: string;
  subscribers: number;
}