import React from 'react';
import { useSubredditStore } from '@/lib/store/subredditStore';
import { SubredditChip } from './SubredditChip';

export function SubredditList() {
  const { subscribedSubreddits, unsubscribe } = useSubredditStore();

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Your Subreddits</h2>
      {subscribedSubreddits.length === 0 ? (
        <p className="text-gray-500">
          You haven't subscribed to any subreddits yet.
        </p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {subscribedSubreddits.map((subreddit) => (
            <SubredditChip
              key={subreddit.id}
              subreddit={subreddit}
              onUnsubscribe={unsubscribe}
            />
          ))}
        </div>
      )}
    </div>
  );
}