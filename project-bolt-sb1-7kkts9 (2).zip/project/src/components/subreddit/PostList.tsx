import React from 'react';
import { useSubredditStore } from '@/lib/store/subredditStore';
import { PostCard } from './PostCard';

export function PostList() {
  const { currentPosts, isLoading } = useSubredditStore();

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600" />
      </div>
    );
  }

  if (currentPosts.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No posts to display. Try subscribing to some subreddits!
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {currentPosts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
    </div>
  );
}