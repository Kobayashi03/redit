import React from 'react';
import { SubredditPost } from '@/lib/types/reddit';
import { formatDate } from '@/lib/utils/date';

interface PostCardProps {
  post: SubredditPost;
}

export function PostCard({ post }: PostCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow">
      <div className="flex items-start space-x-4">
        {post.thumbnail && (
          <img
            src={post.thumbnail}
            alt=""
            className="w-20 h-20 object-cover rounded"
          />
        )}
        <div className="flex-1">
          <h3 className="text-lg font-semibold">
            <a
              href={post.url}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-green-600"
            >
              {post.title}
            </a>
          </h3>
          <div className="text-sm text-gray-500 mt-1">
            <span>Posted by u/{post.author}</span>
            <span className="mx-2">•</span>
            <span>{formatDate(post.created)}</span>
          </div>
          <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
            <span>{post.score} points</span>
            <span>{post.numComments} comments</span>
          </div>
        </div>
      </div>
    </div>
  );
}