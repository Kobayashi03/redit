import React from 'react';
import { Subreddit } from '@/lib/types/reddit';
import { Button } from '@/components/ui/Button';

interface SubredditChipProps {
  subreddit: Subreddit;
  onUnsubscribe: (id: string) => void;
}

export function SubredditChip({ subreddit, onUnsubscribe }: SubredditChipProps) {
  return (
    <div className="inline-flex items-center bg-green-100 rounded-full px-4 py-2">
      <span className="mr-2">{subreddit.displayName}</span>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onUnsubscribe(subreddit.id)}
        className="text-gray-500 hover:text-gray-700 p-1"
      >
        ×
      </Button>
    </div>
  );
}